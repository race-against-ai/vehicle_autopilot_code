arr1 = [156, 189, 219, 262, 301, 33]
arr2 = [107, 512, 512, 23, 267, 250]

curve = True

if curve:
    distance_left = next((val for val in arr1[1::] if val != 512), None)
else:
    distance_left = next((val for val in arr1 if val != 512), None)



print(distance_left)